import os
import logging
from pathlib import Path
from dotenv import load_dotenv
from services.postgres import get_db
from services.boe_fetcher import fetch_boe_xml
from services.parser import parse_and_insert

# Logging
logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")

# Load local .env only if not in GitHub Actions
if os.getenv("GITHUB_ACTIONS") != "true":
    env_path = Path(__file__).resolve().parent.parent / ".env"
    if env_path.exists():
        load_dotenv(dotenv_path=env_path)
        logging.info("🟢 .env file loaded.")
    else:
        logging.warning("⚠️ No .env file found.")

# Ensure OpenAI key is set
api_key = os.getenv("OPENAI_API_KEY")
if not api_key:
    logging.error("❌ OPENAI_API_KEY not found. Check GitHub secrets or .env file.")
    exit(1)
else:
    logging.info("✅ OPENAI_API_KEY loaded successfully.")

# Count current items in PostgreSQL
def get_item_count():
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute("SELECT COUNT(*) FROM items")
        return cur.fetchone()[0]

# Main entry
if __name__ == "__main__":
    logging.info("🚀 Iniciando actualización del BOE...")
    initial_count = get_item_count()

    root = fetch_boe_xml()
    if root is None:
        logging.warning("⚠️ No se pudo obtener el XML del BOE.")
        exit(1)

    inserted_count = parse_and_insert(root)
    final_count = get_item_count()

    logging.info(f"🆕 Ítems nuevos insertados: {inserted_count}")
    logging.info(f"📦 Ítems totales en base de datos: {final_count}")
