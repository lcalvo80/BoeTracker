# services/postgres.py

import os
import psycopg2
from contextlib import contextmanager

DB_URL = os.getenv("DATABASE_URL")

@contextmanager
def get_db():
    conn = psycopg2.connect(DB_URL)
    try:
        yield conn
    finally:
        conn.close()
