# --- FLASK BACKEND (items_controller.py) ---

import psycopg2
import json
import os
from contextlib import contextmanager

DB_URL = os.getenv("DATABASE_URL")

@contextmanager
def get_db():
    conn = psycopg2.connect(DB_URL)
    try:
        yield conn
    finally:
        conn.close()

def dict_rows(cursor):
    columns = [desc[0] for desc in cursor.description]
    return [dict(zip(columns, row)) for row in cursor.fetchall()]

def get_filtered_items(filters, page, limit):
    query = "SELECT * FROM items WHERE 1=1"
    count_query = "SELECT COUNT(*) FROM items WHERE 1=1"
    query_params = []
    count_params = []

    def append_filter(condition, value, exact_match=True):
        nonlocal query, count_query
        if value:
            if exact_match:
                query += f" AND {condition} = %s"
                count_query += f" AND {condition} = %s"
                query_params.append(value)
                count_params.append(value)
            else:
                query += f" AND {condition} ILIKE %s"
                count_query += f" AND {condition} ILIKE %s"
                query_params.append(f"%{value}%")
                count_params.append(f"%{value}%")

    append_filter("identificador", filters.get("identificador"), exact_match=False)
    append_filter("control", filters.get("control"), exact_match=False)
    append_filter("departamento_nombre", filters.get("departamento_nombre"))
    append_filter("epigrafe", filters.get("epigrafe"))
    append_filter("seccion_nombre", filters.get("seccion_nombre"))
    append_filter("fecha_publicacion", filters.get("fecha"))

    query += " ORDER BY fecha_publicacion DESC LIMIT %s OFFSET %s"
    query_params.extend([limit, (page - 1) * limit])

    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute(count_query, count_params)
        total = cursor.fetchone()[0]

        cursor.execute(query, query_params)
        items = dict_rows(cursor)

    return {"items": items, "total": total}

def get_item_by_id(identificador):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM items WHERE identificador = %s", (identificador,))
        row = cursor.fetchone()
        if row:
            columns = [desc[0] for desc in cursor.description]
            return dict(zip(columns, row))
        return {}

def get_item_resumen(identificador):
    item = get_item_by_id(identificador)
    return json.loads(item.get("resumen", "{}")) if item else {}

def get_item_impacto(identificador):
    item = get_item_by_id(identificador)
    return json.loads(item.get("informe_impacto", "{}")) if item else {}

def like_item(identificador):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT likes FROM items WHERE identificador = %s", (identificador,))
        row = cursor.fetchone()
        if row:
            new_count = row[0] + 1
            cursor.execute("UPDATE items SET likes = %s WHERE identificador = %s", (new_count, identificador))
            conn.commit()
            return {"likes": new_count}
        return {}

def dislike_item(identificador):
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT dislikes FROM items WHERE identificador = %s", (identificador,))
        row = cursor.fetchone()
        if row:
            new_count = row[0] + 1
            cursor.execute("UPDATE items SET dislikes = %s WHERE identificador = %s", (new_count, identificador))
            conn.commit()
            return {"dislikes": new_count}
        return {}

def list_clase_items():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT DISTINCT clase_item FROM items WHERE clase_item IS NOT NULL AND clase_item != ''")
        return [row[0] for row in cursor.fetchall()]

def list_departamentos():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT DISTINCT departamento_nombre 
            FROM items 
            WHERE departamento_nombre IS NOT NULL AND departamento_nombre != ''
            ORDER BY departamento_nombre
        """)
        return [row[0] for row in cursor.fetchall() if row[0]]

def list_epigrafes():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT DISTINCT epigrafe 
            FROM items 
            WHERE epigrafe IS NOT NULL AND epigrafe != ''
            ORDER BY epigrafe
        """)
        return [row[0] for row in cursor.fetchall() if row[0]]

def list_secciones():
    with get_db() as conn:
        cursor = conn.cursor()
        cursor.execute("""
            SELECT DISTINCT seccion_nombre 
            FROM items 
            WHERE seccion_nombre IS NOT NULL AND seccion_nombre != ''
            ORDER BY seccion_nombre
        """)
        return [row[0] for row in cursor.fetchall() if row[0]]
