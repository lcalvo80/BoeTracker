-- Esquema para PostgreSQL compatible con el parser actual

CREATE TABLE IF NOT EXISTS items (
    id SERIAL PRIMARY KEY,

    identificador TEXT UNIQUE NOT NULL,
    titulo TEXT,
    titulo_resumen TEXT,

    resumen JSONB,
    informe_impacto JSONB,

    url_pdf TEXT,
    url_html TEXT,
    url_xml TEXT,

    seccion_codigo TEXT,
    seccion_nombre TEXT,

    departamento_codigo TEXT,
    departamento_nombre TEXT,

    epigrafe TEXT,
    control TEXT,

    fecha_publicacion DATE,
    clase_item TEXT,

    likes INTEGER DEFAULT 0,
    dislikes INTEGER DEFAULT 0,

    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS comments (
    id SERIAL PRIMARY KEY,
    item_identificador TEXT NOT NULL REFERENCES items(identificador) ON DELETE CASCADE,
    user_name TEXT,
    comment TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_comment_item ON comments(item_identificador);

-- Trigger para mantener updated_at actualizado automáticamente
CREATE OR REPLACE FUNCTION trigger_set_timestamp()
RETURNS TRIGGER AS $$
BEGIN
   NEW.updated_at = NOW();
   RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS set_timestamp ON items;

CREATE TRIGGER set_timestamp
BEFORE UPDATE ON items
FOR EACH ROW
EXECUTE PROCEDURE trigger_set_timestamp();

-- Índices útiles para filtros y rendimiento
CREATE INDEX IF NOT EXISTS idx_identificador ON items(identificador);
CREATE INDEX IF NOT EXISTS idx_fecha ON items(fecha_publicacion);
CREATE INDEX IF NOT EXISTS idx_departamento ON items(departamento_nombre);
CREATE INDEX IF NOT EXISTS idx_epigrafe ON items(epigrafe);
CREATE INDEX IF NOT EXISTS idx_seccion ON items(seccion_nombre);
CREATE INDEX IF NOT EXISTS idx_clase_item ON items(clase_item);
