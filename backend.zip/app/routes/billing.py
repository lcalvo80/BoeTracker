# app/routes/billing.py
from app.blueprints.billing import bp  # reexporta el blueprint
