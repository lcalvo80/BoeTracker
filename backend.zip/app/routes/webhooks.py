# app/routes/webhooks.py
from app.blueprints.webhooks import bp  # reexporta el blueprint
