# app/routes/__init__.py
# Intencionadamente vacío para evitar imports recursivos/tempranos.
# Puedes mantener __all__ si quieres autocompletado, pero sin importar submódulos.
__all__ = ["items", "comments"]
