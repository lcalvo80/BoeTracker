ENTITLEMENTS = {
  "free":        {"featureA": True,  "featureB": False, "exportCSV": False},
  "pro":         {"featureA": True,  "featureB": True,  "exportCSV": True},
  "enterprise":  {"featureA": True,  "featureB": True,  "exportCSV": True},
}
