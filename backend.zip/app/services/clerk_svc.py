import httpx
from flask import current_app
from typing import Any, Dict, List

API_BASE = "https://api.clerk.com/v1"

def _headers():
    sk = current_app.config.get("CLERK_SECRET_KEY") or ""
    if not sk:
        raise RuntimeError("CLERK_SECRET_KEY not configured")
    return {
        "Authorization": f"Bearer {sk}",
        "Content-Type": "application/json",
    }

def get_user(user_id: str):
    r = httpx.get(f"{API_BASE}/users/{user_id}", headers=_headers(), timeout=10)
    r.raise_for_status()
    return r.json()

def get_org(org_id: str):
    r = httpx.get(f"{API_BASE}/organizations/{org_id}", headers=_headers(), timeout=10)
    r.raise_for_status()
    return r.json()

def get_user_memberships(user_id: str) -> List[Dict[str, Any]]:
    r = httpx.get(
        f"{API_BASE}/users/{user_id}/organization_memberships",
        headers=_headers(),
        timeout=10,
    )
    r.raise_for_status()
    data = r.json()
    return data if isinstance(data, list) else (data.get("data") or [])

def update_user_metadata(user_id: str, public: dict | None=None, private: dict | None=None):
    payload = {}
    if public is not None: payload["public_metadata"] = public
    if private is not None: payload["private_metadata"] = private
    if not payload:
        return get_user(user_id)
    r = httpx.patch(f"{API_BASE}/users/{user_id}", headers=_headers(), json=payload, timeout=10)
    r.raise_for_status()
    return r.json()

def update_org_metadata(org_id: str, public: dict | None=None, private: dict | None=None):
    payload = {}
    if public is not None: payload["public_metadata"] = public
    if private is not None: payload["private_metadata"] = private
    if not payload:
        return get_org(org_id)
    r = httpx.patch(f"{API_BASE}/organizations/{org_id}", headers=_headers(), json=payload, timeout=10)
    r.raise_for_status()
    return r.json()

def create_org_for_user(user_id: str, name: str, public: dict | None=None, private: dict | None=None):
    payload: Dict[str, Any] = {"name": name, "created_by": user_id}
    if public is not None:
        payload["public_metadata"] = public
    if private is not None:
        payload["private_metadata"] = private
    r = httpx.post(f"{API_BASE}/organizations", headers=_headers(), json=payload, timeout=10)
    r.raise_for_status()
    return r.json()

# Helpers
def set_user_plan(user_id: str, plan: str, status: str | None = None, extra_private: dict | None=None, extra_public: dict | None=None):
    pub = {"plan": plan}
    if status is not None: pub["status"] = status
    if extra_public: pub.update(extra_public)
    priv = extra_private or {}
    return update_user_metadata(user_id, public=pub, private=priv)

def set_org_plan(org_id: str, plan: str, status: str | None = None, extra_private: dict | None=None, extra_public: dict | None=None):
    pub = {"plan": plan}
    if status is not None: pub["status"] = status
    if extra_public: pub.update(extra_public)
    priv = extra_private or {}
    return update_org_metadata(org_id, public=pub, private=priv)

# (Opcional) invitado enterprise por email
def find_users_by_email(email: str) -> List[Dict[str, Any]]:
    r = httpx.get(f"{API_BASE}/users", params={"email_address": email}, headers=_headers(), timeout=10)
    r.raise_for_status()
    data = r.json()
    return data if isinstance(data, list) else (data.get("data") or [])

def create_user_skeleton(email: str) -> Dict[str, Any]:
    payload = {"email_address": [email], "skip_password_requirement": True}
    r = httpx.post(f"{API_BASE}/users", headers=_headers(), json=payload, timeout=10)
    r.raise_for_status()
    return r.json()

def ensure_user_by_email(email: str) -> Dict[str, Any]:
    found = find_users_by_email(email)
    if found:
        return found[0] if isinstance(found, list) else found
    return create_user_skeleton(email)
